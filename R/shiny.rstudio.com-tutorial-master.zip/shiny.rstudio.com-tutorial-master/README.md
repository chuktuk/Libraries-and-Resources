# shiny.rstudio.com-tutorial

This repository contains the slides and exercises for the video tutorial at https://shiny.rstudio.com/tutorial. You can either clone the repository or download its contents as a zipped folder by clicking on the green "Clone or download" button on the upper right corner.
